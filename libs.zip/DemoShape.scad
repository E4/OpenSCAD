$fn=200;

module demoshape()
{
    function r_from_dia(d) = d / 2;

    module rotcy(rot, r, h) {
        rotate(90, rot)
        cylinder(r = r, h = h, center = true);
    }

    difference() {
        intersection() {
            color("#f30") cube([size*0.8,size*0.8,size*0.8], center = true);
            color("#f00") sphere(r = r_from_dia(size));
        }
        color("#f80") rotcy([0, 0, 0], cy_r, cy_h);
        color("#f80") rotcy([1, 0, 0], cy_r, cy_h);
        color("#f80") rotcy([0, 1, 0], cy_r, cy_h);
        for (x_idx = [0 : 1]) {
            for (y_idx = [0 : 3]) {
                color("#fc6") 
                rotate([-35+x_idx*70, y_idx * 90+45, 0])
                translate([0, 0 , 24])
                linear_extrude(1)
                text(str((x_idx * 4) + y_idx + 1), halign="center", valign="center");
            }
        }
    }

    size = 50;
    hole = 25;

    cy_r = r_from_dia(hole);
    cy_h = r_from_dia(size * 2.5);
}

echo(version=version());

demoshape();
